from .python import swish_binding as _swish_binding

Swish = _swish_binding.Swish
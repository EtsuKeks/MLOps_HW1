Check opened PRs
